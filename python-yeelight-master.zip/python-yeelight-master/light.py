from yeelight import Bulb
from ultralytics import YOLO
bulb = Bulb("192.168.184.73")
bulb.turn_on()
